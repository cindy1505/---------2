#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>

#define SENSOR_PORT  PINF
#define MOTORPORT1 PORTB

#define ON     1
#define OFF     0
#define CW     1
#define CCW     0

void port_init(void)
{
 PORTA = 0x00;
 DDRA  = 0x00;
 PORTB = 0x00;
 DDRB  = 0xff;
 PORTC = 0x00; //m103 output only
 DDRC  = 0xff;
 PORTD = 0x00;
 DDRD  = 0x00;
 PORTE = 0x00;
 DDRE  = 0x00;
 PORTF = 0x00;
 DDRF  = 0x00;
 PORTG = 0x00;
 
 
 DDRG  = 0x03;
}

// UART0 을 이용한 출력
void tx0Char(char message)
{
 while (((UCSR0A>>UDRE0)&0x01) == 0) ;  // UDRE, data register empty        
    UDR0 = message;
}


static int Putchar(char c, FILE *stream)
{
 tx0Char(c);
    return 0;
      
}

//UART0 initialize
// c
// actual: baud rate:9615 (0.2%)
// char size: 8 bit
// parity: Disabled  패리티 : 사용 안 함
void uart0_init(void)
{
 UCSR0B = 0x00; //disable while setting baud rate 전송 속도를 설정하는 동안 비활성화
 UCSR0A = 0x00;
 UCSR0C = 0x06;
 UBRR0L = 0x67; //set baud rate lo 세트 전송 속도 낮다
 UBRR0H = 0x00; //set baud rate hi 세트 전송 속도 높다
 UCSR0B = 0x18;
}

//call this routine to initialize all peripherals  모든 주변 장치를 초기화하는 이 루틴을 호출
void init_devices(void)
{
 //stop errant interrupts until set up 설정 될 때까지 잘못된 인터럽트를 중지
 cli(); //disable all interrupts
 XMCRA = 0x00; //external memory
 XMCRB = 0x00; //external memory
 port_init();
 uart0_init();
 fdevopen(Putchar,0);  
 
 MCUCR = 0x00;
 EICRA = 0x00; //extended ext ints
 EICRB = 0x00; //extended ext ints
 EIMSK = 0x00;
 TIMSK = 0x00; //timer interrupt sources
 ETIMSK = 0x00; //extended timer interrupt sources
 
 sei(); //re-enable interrupts
 //all peripherals are now initialized

}

void delay(int n)
{
 volatile int i,j;
 for(i=1;i<n;i++)
 {
     for(j=1;j<600;j++);
 }
}

void delay2(int n)
{
 volatile int i,j;
 for(i=1;i<n;i++)
 {
     for(j=1;j<10;j++);
 }
}

void M1A(int onoff){
 if(onoff==ON)
  MOTORPORT1 = MOTORPORT1|0x01;
 else
  MOTORPORT1 = MOTORPORT1&0xFE;  
}

void M1A_(int onoff){
 if(onoff==ON)
  MOTORPORT1 = MOTORPORT1|0x02;
 else
  MOTORPORT1 = MOTORPORT1&0xFD;  
}

void M1B(int onoff){
 if(onoff==ON)
  MOTORPORT1 = MOTORPORT1|0x04;
 else
  MOTORPORT1 = MOTORPORT1&0xFB;  
}

void M1B_(int onoff){
 if(onoff==ON)
  MOTORPORT1 = MOTORPORT1|0x08;
 else
  MOTORPORT1 = MOTORPORT1&0xF7;  
}





//오른쪽 왼쪽 하나식 선언

void Motor1(int CWCCW){
 if(CWCCW==CW){
  M1A(ON);
 M1A_(OFF);
 }else{
  M1A(OFF);
 M1A_(ON);
 }
}

void Motor2(int CWCCW){
 if(CWCCW==CW){
  M1B(ON);
 M1B_(OFF);
 }else{
  M1B(OFF);
 M1B_(ON);
 }
}


void MOTORSTOP(void){
  M1B(OFF);
 M1B_(OFF);
  M1A(OFF);
 M1A_(OFF);
}

//
int main(void)
{
 unsigned char sensor;
// volatile unsigned char stepleft=0, stepright=0;
 
 init_devices();
 
 while(1){
     sensor = SENSOR_PORT & 0x0F;

  printf("\r\n Sensor:%x    ",sensor);
  switch(sensor){
   /*case 0x00:  printf("Nothing\r\n");
      PORTG= 0x01;
      break;
   case 0x08:  printf("RIGHTEST\r\n");    
      PORTG= 0x02;
      break;
   case 0x04:  printf("RIGHT\r\n");
      PORTG= 0x03;
      break;
   case 0x03:
   case 0x02:  printf("LEFT\r\n");
         PORTG= 0x00;
         break;
   case 0x01:  printf("LEFTEST\r\n");
      PORTG= 0x03;
      break;*/

   case 0x03:
   case 0x07:  printf("맨오른쪽 \r\n");
      PORTG= 0x01;
      Motor1(0);
      M1B(OFF);
      M1B_(OFF);
      delay(17);
      MOTORSTOP();
      delay2(1);

//      Motor2(0);
      //Motor2(0);
      break;
   case 0x0b:  printf("오른쪽 \r\n");    
      PORTG= 0x02;
      Motor1(0);
      M1B(OFF);
      M1B_(OFF);
      delay(17);
      MOTORSTOP();
      delay2(1);

//      
//      Motor2(0);
      break;
   case 0x0c:
   case 0x0d:  printf("왼쪽 \r\n");
      PORTG= 0x03;
      //Motor1(1);
      M1A(OFF);
      M1A_(OFF);
      Motor2(1);
      delay(14);
      MOTORSTOP();
      delay2(1);

      break;
   case 0x0e:  printf("맨왼쪽\r\n");
         PORTG= 0x00;
      //Motor1(1);
      M1A(OFF);
      M1A_(OFF);
      Motor2(1);
      delay(14);
      MOTORSTOP();
      delay2(16);

      break;
   case 0x0f:  printf("All White");
      Motor1(0);
      Motor2(1);
      delay(15);
      MOTORSTOP();
      //M1A(OFF);
      //M1A_(OFF);
      //Motor2(1);
      //delay(50);
      //MOTORSTOP();
      
      delay2(1);
      break;

   default :   printf("예외\r\n");
      M1A(OFF);
      M1A_(OFF);
      M1B(OFF);
      M1B_(OFF);
         //Motor1(0);
      //Motor2(1);
      break;
   
  }  
 }
 return 0;
 }